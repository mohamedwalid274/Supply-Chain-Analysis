# Python Analysis

Run the notebooks in order:

1. `01_data_loading_cleaning.ipynb` — loading, data-quality checks, cleaning, Gross Sales, and outlier detection.
2. `02_exploratory_data_analysis.ipynb` — product analysis, dimension keys, and star-schema exports.

The notebooks include explanatory Markdown sections and comments for portfolio review.
